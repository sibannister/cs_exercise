package offers;

import checkout.BasketItem;

public final class BuyOneGetOneFree extends MultiBuy {
    private static final String NAME = "Buy One Get One Free";
    private static final int THRESHOLD = 2;

    public BuyOneGetOneFree() {
        super(THRESHOLD);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected boolean isSpecialOfferItem(BasketItem basketItem) {
        return basketItem.isBuyOneGetOneFree();
    }
}
