package offers;

import checkout.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;

public abstract class MultiBuy extends ReceiptObserver {
    private final int threshold;
    private Map<BasketItem, Integer> specialOfferItems = new HashMap<>();

    protected MultiBuy(int threshold) {
        this.threshold = threshold;
    }

    public abstract String getName();

    @Override
    public void update(Observable observable, Object o) {
        if (isInvoiceReceiptItem(observable)) {
            processInvoiceItem((Receipt)observable);
        }
    }

    protected abstract boolean isSpecialOfferItem(BasketItem basketItem);

    private boolean isInvoiceReceiptItem(Observable observable) {
        return (observable instanceof Receipt && ((Receipt) observable).getCurrentItem() instanceof InvoiceItem);
    }

    private void processInvoiceItem(Receipt receipt) {
        BasketItem basketItem = ((InvoiceItem) getCurrentItem(receipt)).getBasketItem();
        if(isSpecialOfferItem(basketItem)) {
            incrementSpecialOfferItem(receipt, basketItem);
        }
    }

    private void incrementSpecialOfferItem(Receipt receipt, BasketItem basketItem) {
        if (!specialOfferItems.containsKey(basketItem)) {
            addSpecialOffer(basketItem);
        }
        int quantity = specialOfferItems.get(basketItem);
        specialOfferItems.replace(basketItem, ++quantity);
        if(dealFulfilled(quantity)) {
            BigDecimal discount = basketItem.getPrice().negate();
            receipt.addDiscount(new DiscountItem(this, discount));
        }
    }

    private void addSpecialOffer(BasketItem basketItem) {
        Integer initialize = Integer.valueOf(0);
        specialOfferItems.put(basketItem, initialize);
    }

    private boolean dealFulfilled(int quantity) {
        final int noRemainder = 0;
        return quantity % threshold == noRemainder;
    }
}
