package offers;

import checkout.BasketItem;

public final class BuyThreeForTwo extends MultiBuy {
    private static final String NAME = "Three for Two";
    private static final int THRESHOLD = 3;

    public BuyThreeForTwo() {
        super(THRESHOLD);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    protected boolean isSpecialOfferItem(BasketItem basketItem) {
        return basketItem.isBuyThreeForTwo();
    }
}
