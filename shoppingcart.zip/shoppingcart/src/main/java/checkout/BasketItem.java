package checkout;

import java.math.BigDecimal;

public enum BasketItem {
    APPLE("Apple", BigDecimal.valueOf(0.35), false, false),
    BANANA("Banana", BigDecimal.valueOf(0.20), false, false),
    MELON("Melon", BigDecimal.valueOf(0.50), true, false),
    LIME("Lime", BigDecimal.valueOf(0.15), false, true);

    private final String name;
    private final BigDecimal price;
    private final boolean isBuyOneGetOneFree;
    private final boolean isBuyThreeForTwo;

    BasketItem(String name, BigDecimal price, boolean isBuyOneGetOneFree, boolean isBuyThreeForTwo) {
        this.name = name;
        this.price = price;
        this.isBuyOneGetOneFree = isBuyOneGetOneFree;
        this.isBuyThreeForTwo = isBuyThreeForTwo;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public boolean isBuyOneGetOneFree() { return isBuyOneGetOneFree; }

    public boolean isBuyThreeForTwo() { return isBuyThreeForTwo; }
}
