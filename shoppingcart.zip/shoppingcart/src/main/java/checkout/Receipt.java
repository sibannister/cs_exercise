package checkout;

import offers.MultiBuy;
import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.Observable;

public class Receipt extends Observable {
    private TotalTracker totalTracker;
    private ReceiptPrinter receiptPrinter;
    private ReceiptItem currentItem;
    private LinkedList<DiscountItem> discounts = new LinkedList<>();

    public Receipt(MultiBuy... multiBuys) {
        this(new TotalTracker(), new ReceiptPrinter(),multiBuys);
    }

    public Receipt(TotalTracker totalTracker, ReceiptPrinter receiptPrinter, MultiBuy ... multiBuys) {
        if(totalTracker == null) {
            throw new IllegalArgumentException("totalTracker cannot be null");
        }
        if(receiptPrinter == null) {
            throw new IllegalArgumentException("receiptPrinter cannot be null");
        }

        this.totalTracker = totalTracker;
        this.receiptPrinter = receiptPrinter;
        addObserver(totalTracker);
        addObserver(receiptPrinter);
        for (MultiBuy multiBuy: multiBuys) {
            addObserver(multiBuy);
        }
    }

    public BigDecimal getTotal() {
        BigDecimal total = totalTracker.getTotal();
        receiptPrinter.printTotal(total);
        return total;
    }

    public void setItem(ReceiptItem receiptItem) {
        currentItem = receiptItem;
        setChanged();
        notifyObservers();
        while (discounts.peek() != null) {
            setItem(discounts.removeFirst());
        }
    }

    public void addDiscount(DiscountItem discountItem) {
        discounts.addLast(discountItem);
    }

    public ReceiptItem getCurrentItem() {
        return currentItem;
    }
}
