package checkout;

import offers.MultiBuy;

import java.math.BigDecimal;

public class DiscountItem extends ReceiptItem {
    public DiscountItem(MultiBuy description, BigDecimal reduction) {
        super(description.getName(), reduction);
    }
}
