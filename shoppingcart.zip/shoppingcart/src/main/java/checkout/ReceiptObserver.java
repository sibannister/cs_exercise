package checkout;

import java.util.Observer;

public abstract class ReceiptObserver implements Observer {
    protected ReceiptItem getCurrentItem(Receipt receipt) {
        return receipt.getCurrentItem();
    }
}
