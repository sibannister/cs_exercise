package checkout;

public class InvoiceItem extends ReceiptItem {
    private final BasketItem basketItem;

    public InvoiceItem(BasketItem basketItem) {
        super(basketItem.getName(), basketItem.getPrice());
        this.basketItem = basketItem;
    }

    public BasketItem getBasketItem() {
        return basketItem;
    }
}
