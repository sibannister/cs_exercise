package checkout;

import java.math.BigDecimal;
import java.util.Observable;

public class TotalTracker extends ReceiptObserver {
    public static final int GBP_PRECISION = 2;
    private BigDecimal subTotal = BigDecimal.ZERO;

    @Override
    public void update(Observable observable, Object o) {
        if (observable instanceof Receipt) {
            ReceiptItem currentItem = getCurrentItem((Receipt) observable);
            subTotal = subTotal.add(currentItem.getPrice());
            if(subTotal.compareTo(BigDecimal.ZERO) < 0) {
                throw new ArithmeticException("subTotal cannot be less than zero");
            }
        }
    }

    public BigDecimal getTotal() {
        return subTotal.setScale(GBP_PRECISION);
    }
}
