package checkout;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Observable;


public class ReceiptPrinter extends ReceiptObserver {
    public static final String MESSAGE_PATTERN = "{0}    {1}";
    public static final String TOTAL_DESCRIPTION = "TOTAL=";
    @Override
    public void update(Observable observable, Object o) {
        if (observable instanceof Receipt) {
            ReceiptItem item = getCurrentItem((Receipt)observable);
            System.out.println(MessageFormat.format(MESSAGE_PATTERN, item.getDescription(), item.getPrice()));
        }
    }

    public void printTotal(BigDecimal total) {
        if (total == null) {
            throw new IllegalArgumentException("total cannot be null");
        }
        System.out.println(MessageFormat.format(MESSAGE_PATTERN, TOTAL_DESCRIPTION, total));
    }
}
