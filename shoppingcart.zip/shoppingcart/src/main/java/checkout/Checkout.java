package checkout;

import offers.BuyOneGetOneFree;
import offers.BuyThreeForTwo;

import java.math.BigDecimal;
import java.util.List;


public final class Checkout {

    public BigDecimal scan(List<String> basket) {
        Receipt receipt = new Receipt(new BuyOneGetOneFree(), new BuyThreeForTwo());
        if (basket!= null) {
            for (String basketItem : basket) {
                receipt.setItem(new InvoiceItem(BasketItem.valueOf(basketItem.toUpperCase())));
            }
        }
        return receipt.getTotal();
    }
}
