import checkout.Checkout;

import java.util.Arrays;
import java.util.List;

public class App {
    public static void main(String[] args) {
        List<String> basketItems = Arrays.asList(args);
        Checkout checkout = new Checkout();
        checkout.scan(basketItems);
    }
}
