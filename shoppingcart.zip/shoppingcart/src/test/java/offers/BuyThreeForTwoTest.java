package offers;

import checkout.BasketItem;
import checkout.DiscountItem;
import checkout.InvoiceItem;
import checkout.Receipt;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class BuyThreeForTwoTest {
    private BuyThreeForTwo buyThreeForTwo;
    private Receipt receipt;

    @BeforeEach
    void setUp() {
        buyThreeForTwo = new BuyThreeForTwo();
        receipt = mock(Receipt.class);
    }

    @Test
    void shouldNotAddDiscountToReceipt() {
        InvoiceItem limeInvoiceItem = mock(InvoiceItem.class);
        when(limeInvoiceItem.getBasketItem()).thenReturn(BasketItem.LIME);
        when(receipt.getCurrentItem()).thenReturn(limeInvoiceItem);
        buyThreeForTwo.update(receipt, null);

        verify(receipt, never()).addDiscount(any());
    }

    @Test
    void shouldNotAddDiscountForDifferentSpecial() {
        InvoiceItem melonInvoiceItem = mock(InvoiceItem.class);
        when(melonInvoiceItem.getBasketItem()).thenReturn(BasketItem.MELON);
        when(receipt.getCurrentItem()).thenReturn(melonInvoiceItem);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);

        verify(receipt, never()).addDiscount(any());
    }

    @Test
    void shouldNotAddDiscountForNonSpecial() {
        InvoiceItem appleInvoiceItem = mock(InvoiceItem.class);
        when(appleInvoiceItem.getBasketItem()).thenReturn(BasketItem.APPLE);
        when(receipt.getCurrentItem()).thenReturn(appleInvoiceItem);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);

        verify(receipt, never()).addDiscount(any());
    }


    @Test
    void shouldAddDiscountToReceipt() {
        InvoiceItem limeInvoiceItem = mock(InvoiceItem.class);
        when(limeInvoiceItem.getBasketItem()).thenReturn(BasketItem.LIME);
        when(receipt.getCurrentItem()).thenReturn(limeInvoiceItem);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);

        verify(receipt).addDiscount(any());
    }

    @Test
    void shouldAddDiscountTwiceToReceipt() {
        InvoiceItem limeInvoiceItem = mock(InvoiceItem.class);
        when(limeInvoiceItem.getBasketItem()).thenReturn(BasketItem.LIME);
        when(receipt.getCurrentItem()).thenReturn(limeInvoiceItem);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);
        buyThreeForTwo.update(receipt, null);

        final int twice = 2;
        verify(receipt,times(twice)).addDiscount(any());
    }

    @Test
    void shouldDoNothingForNonInvoiceItem() {
        DiscountItem discountItem = mock(DiscountItem.class);
        when(receipt.getCurrentItem()).thenReturn(discountItem);
        verify(receipt, never()).addDiscount(any());
    }
}