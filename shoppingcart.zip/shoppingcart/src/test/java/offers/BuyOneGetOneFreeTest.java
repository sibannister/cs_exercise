package offers;

import checkout.BasketItem;
import checkout.DiscountItem;
import checkout.InvoiceItem;
import checkout.Receipt;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

class BuyOneGetOneFreeTest {
    private BuyOneGetOneFree buyOneGetOneFree;
    private Receipt receipt;

    @BeforeEach
    void setUp() {
        buyOneGetOneFree = new BuyOneGetOneFree();
        receipt = mock(Receipt.class);
    }

    @Test
    void shouldNotAddDiscountToReceipt() {
        InvoiceItem melonInvoiceItem = mock(InvoiceItem.class);
        when(melonInvoiceItem.getBasketItem()).thenReturn(BasketItem.MELON);
        when(receipt.getCurrentItem()).thenReturn(melonInvoiceItem);
        buyOneGetOneFree.update(receipt, null);

        verify(receipt, never()).addDiscount(any());
    }

    @Test
    void shouldNotAddDiscountForDifferentSpecial() {
        InvoiceItem limeInvoiceItem = mock(InvoiceItem.class);
        when(limeInvoiceItem.getBasketItem()).thenReturn(BasketItem.LIME);
        when(receipt.getCurrentItem()).thenReturn(limeInvoiceItem);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);

        verify(receipt, never()).addDiscount(any());
    }

    @Test
    void shouldNotAddDiscountForNonSpecial() {
        InvoiceItem appleInvoiceItem = mock(InvoiceItem.class);
        when(appleInvoiceItem.getBasketItem()).thenReturn(BasketItem.APPLE);
        when(receipt.getCurrentItem()).thenReturn(appleInvoiceItem);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);

        verify(receipt, never()).addDiscount(any());
    }


    @Test
    void shouldAddDiscountToReceipt() {
        InvoiceItem melonInvoiceItem = mock(InvoiceItem.class);
        when(melonInvoiceItem.getBasketItem()).thenReturn(BasketItem.MELON);
        when(receipt.getCurrentItem()).thenReturn(melonInvoiceItem);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);

        verify(receipt).addDiscount(any());
    }

    @Test
    void shouldAddDiscountTwiceToReceipt() {
        InvoiceItem melonInvoiceItem = mock(InvoiceItem.class);
        when(melonInvoiceItem.getBasketItem()).thenReturn(BasketItem.MELON);
        when(receipt.getCurrentItem()).thenReturn(melonInvoiceItem);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);
        buyOneGetOneFree.update(receipt, null);

        final int twice = 2;
        verify(receipt,times(twice)).addDiscount(any());
    }

    @Test
    void shouldDoNothingForNonInvoiceItem() {
        DiscountItem discountItem = mock(DiscountItem.class);
        when(receipt.getCurrentItem()).thenReturn(discountItem);
        verify(receipt, never()).addDiscount(any());
    }

}