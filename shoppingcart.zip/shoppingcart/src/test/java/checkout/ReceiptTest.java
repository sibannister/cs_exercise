package checkout;

import offers.MultiBuy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReceiptTest {
    private Receipt receipt;
    private TotalTracker totalTracker;
    private ReceiptPrinter receiptPrinter;
    private MultiBuy multiBuy;

    @BeforeEach
    void setUp() {
        totalTracker = mock(TotalTracker.class);
        receiptPrinter = mock(ReceiptPrinter.class);
        multiBuy = mock(MultiBuy.class);
        receipt = new Receipt(totalTracker, receiptPrinter, multiBuy);
    }

    @Test
    void shouldThrowExceptionForMissingTotalTracker() {
        assertThrows(IllegalArgumentException.class, () -> new Receipt(null, receiptPrinter, multiBuy));
    }

    @Test
    void shouldThrowExceptionForMissingReceiptPrinter() {
        assertThrows(IllegalArgumentException.class, () -> new Receipt(totalTracker, null, multiBuy));
    }

    @Test
    void shouldNotifyObserversWhenItemSet() {
        ReceiptItem receiptItem = mock(ReceiptItem.class);
        receipt.setItem(receiptItem);
        verify(totalTracker).update(receipt, null);
        verify(receiptPrinter).update(receipt, null);
        verify(multiBuy).update(receipt, null);
    }

    @Test
    void shouldPrintAndGetTotal() {
        BigDecimal total = BigDecimal.ZERO;
        when(totalTracker.getTotal()).thenReturn(total);

        BigDecimal result = receipt.getTotal();
        verify(totalTracker).getTotal();
        verify(receiptPrinter).printTotal(total);
        assertEquals(total, result);
    }
}