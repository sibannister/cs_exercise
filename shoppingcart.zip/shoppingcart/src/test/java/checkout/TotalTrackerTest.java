package checkout;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static java.util.stream.Collectors.toList;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TotalTrackerTest {
    private TotalTracker totalTracker;
    private Receipt receipt;

    @BeforeEach
    void setUp() {
        totalTracker = new TotalTracker();
        receipt = mock(Receipt.class);
    }

    @Test
    void shouldUpdateAccumulateTotal() {
        BasketItem apple = BasketItem.APPLE;
        InvoiceItem appleInvoice = createInvoiceItem(apple);
        final int quantity = 5;
        applyMultipleReceiptItems(appleInvoice, quantity);
        BigDecimal expectedTotal = apple.getPrice().multiply(BigDecimal.valueOf(quantity));
        expectedTotal.setScale(TotalTracker.GBP_PRECISION);
        assertEquals(expectedTotal,totalTracker.getTotal());
    }

    @Test
    void shouldAccumulateAndApplyDiscounts() {
        BasketItem apple = BasketItem.APPLE;
        InvoiceItem appleInvoice = createInvoiceItem(apple);
        final int quantity = 5;
        applyMultipleReceiptItems(appleInvoice, quantity);

        final int freeApples = 1;
        DiscountItem discountApple = createDiscountItem(BasketItem.APPLE.getPrice());
        applyMultipleReceiptItems(discountApple, freeApples);

        BigDecimal expectedTotal = apple.getPrice().multiply(BigDecimal.valueOf(quantity - freeApples));
        expectedTotal.setScale(TotalTracker.GBP_PRECISION);
        assertEquals(expectedTotal,totalTracker.getTotal());
    }

    @Test
    void shouldThrowArithmeticExceptionForNegativeSubTotal() {
        DiscountItem discountApple = createDiscountItem(BasketItem.APPLE.getPrice());
        when(receipt.getCurrentItem()).thenReturn(discountApple);
        assertThrows(ArithmeticException.class, () -> totalTracker.update(receipt, null));
    }

    private void applyMultipleReceiptItems(ReceiptItem receiptItem, int quantity) {
        when(receipt.getCurrentItem()).thenReturn(receiptItem);
        for(int receiptItems = 0; receiptItems < quantity; receiptItems++) {
            totalTracker.update(receipt, null);
        }
    }

    private InvoiceItem createInvoiceItem(BasketItem basketItem) {
        InvoiceItem invoiceItem = mock(InvoiceItem.class);
        when(invoiceItem.getBasketItem()).thenReturn(basketItem);
        when(invoiceItem.getPrice()).thenReturn(basketItem.getPrice());
        return invoiceItem;
    }

    private DiscountItem createDiscountItem(BigDecimal discount) {
        DiscountItem discountItem = mock(DiscountItem.class);
        when(discountItem.getPrice()).thenReturn(discount.negate());
        when(discountItem.getDescription()).thenReturn("DISCOUNT");
        return discountItem;
    }
}