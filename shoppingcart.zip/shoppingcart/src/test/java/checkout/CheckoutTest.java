package checkout;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;



class CheckoutTest {
    private Checkout checkout;

    @BeforeEach
    void setUp() {
        checkout = new Checkout();
    }

    @Test
    void shouldScanListOfNames() {
        BigDecimal expectedTotal = BigDecimal.ZERO;
        for (BasketItem item: BasketItem.values()) {
            expectedTotal = expectedTotal.add(item.getPrice());
        }
        List<String> items = Stream.of(BasketItem.values()).map(BasketItem::getName).collect(toList());
        BigDecimal total = checkout.scan(items);
        assertEquals(expectedTotal, total);
    }

    @Test
    void shouldReturnZeroForEmptyList() {
        final BigDecimal expectedTotal = BigDecimal.ZERO.setScale(TotalTracker.GBP_PRECISION);
        List<String> items = new ArrayList<>();
        BigDecimal total = checkout.scan(items);
        assertEquals(expectedTotal, total);
    }

    @Test
    void shouldReturnZeroForNullList() {
        final BigDecimal expectedTotal = BigDecimal.ZERO.setScale(TotalTracker.GBP_PRECISION);
        BigDecimal total = checkout.scan(null);
        assertEquals(expectedTotal, total);
    }

    @Test
    void shouldThrowExceptionForUnknownItem() {
        final String unknownItem = "Goat";
        String[] basket = {BasketItem.APPLE.getName(), unknownItem, BasketItem.LIME.getName()};
        List<String> items = Arrays.stream(basket).collect(toList());
        assertThrows(IllegalArgumentException.class, () -> checkout.scan(items));
    }

    @Test
    void shouldDetectBuyOneGetOneFreeTest() {
        final BigDecimal expectedTotal = BasketItem.MELON.getPrice().setScale(TotalTracker.GBP_PRECISION);
        ArrayList<String> basket = new ArrayList<>();
        int numberOfMelons = 2;
        addBasketItems(basket, numberOfMelons, BasketItem.MELON);
        BigDecimal total = checkout.scan(basket);
        assertEquals(expectedTotal, total);
    }

    @Test
    void shouldDetectThreeForTwo() {
        final BigDecimal expectedTotal = BasketItem.LIME.getPrice().add(BasketItem.LIME.getPrice());
        ArrayList<String> basket = new ArrayList<>();
        int numberOfLimes = 3;
        addBasketItems(basket, numberOfLimes, BasketItem.LIME);
        BigDecimal total = checkout.scan(basket);
        assertEquals(expectedTotal, total);
    }

    private void addBasketItems(List<String> basket, int quantity, BasketItem basketItem) {
        for(int numberOfItems = 0; numberOfItems < quantity; numberOfItems++) {
            basket.add(basketItem.getName());
        }
    }
}