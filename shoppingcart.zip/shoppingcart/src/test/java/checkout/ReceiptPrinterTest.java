package checkout;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.text.MessageFormat;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReceiptPrinterTest {
    private ReceiptPrinter receiptPrinter;
    private Receipt receipt;
    private ByteArrayOutputStream output;

    @BeforeEach
    void setUp() {
        receiptPrinter = new ReceiptPrinter();
        receipt = mock(Receipt.class);
        output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));
    }

    @AfterEach
    void teardown() {
        System.setOut(null);
    }

    @Test
    void shouldPrintReceiptItem() {
        ReceiptItem receiptItem = mock(ReceiptItem.class);
        final String description = "DESCRIPTION";
        when(receiptItem.getDescription()).thenReturn(description);
        final BigDecimal price = BigDecimal.valueOf(0.10);
        when(receiptItem.getPrice()).thenReturn(price);
        when(receipt.getCurrentItem()).thenReturn(receiptItem);
        receiptPrinter.update(receipt, null);
        String expectedDescription = MessageFormat.format(ReceiptPrinter.MESSAGE_PATTERN, description, price);
        assertEquals(expectedDescription, output.toString().trim());
    }

    @Test
    void shouldThrowExceptionIfTotalIsNull() {
        assertThrows(IllegalArgumentException.class, () -> receiptPrinter.printTotal(null));
    }

    @Test
    void shouldPrintTotalDescription() {
        BigDecimal total = BigDecimal.valueOf(101.01);
        receiptPrinter.printTotal(total);
        String expectedDescription = MessageFormat.format(ReceiptPrinter.MESSAGE_PATTERN, ReceiptPrinter.TOTAL_DESCRIPTION, total);
        assertEquals(expectedDescription, output.toString().trim());
    }
 }